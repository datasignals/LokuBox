export const Hello = () => {
    console.log("Hello world")
}